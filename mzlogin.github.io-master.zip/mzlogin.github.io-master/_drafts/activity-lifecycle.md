---
layout: post
title: template page
categories: Android
description: 深入理解 Android 的进程、Task、Activity 等之间的关系。
keywords: Android, Task, Activity, 进程
---

